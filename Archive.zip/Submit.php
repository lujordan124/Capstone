<?php

	/* 	===============================================================
		Check login
		=============================================================== */

	require "CheckLogin.php";




	/* 	===============================================================
		Get quizID, questionNumber, submission, grade or redirect
		=============================================================== */
	
	if (!isset($_POST["quizID"]) || !isset($_POST["questionNumber"]) 
		|| !isset($_POST["submission"]) || !isset($_POST["grade"])) {
		$newURL = "error.html";
		header("Location: '.$newURL");
	}
	$quizID = $_POST["quizID"];
	$questionNumber = $_POST["questionNumber"];
	$submission = $_POST["submission"];
	$grade = $_POST["grade"]; 
	


	/* 	===============================================================
		Create student's file submission based on language requirement
		=============================================================== */	

	$mongo = new MongoClient(); 
	$db = $mongo->selectDB("capstone");
	$cursor = $db->quizzes->find(array("quizID" => $quizID));

	foreach ($cursor as $document) {
		$language = $document["language"];
		$numSubmission = $document["numSubmission"];
	}

	if ($language == "C") {
		$studentFile = $quizID . $studentID . $questionNumber . ".c";
		$gradeFile = $quizID . $questionNumber . ".c";
	}
	else {
		$studentFile = $quizID . $id . $questionNumber . ".c";
		$gradeFile = $quizID . $questionNumber . ".c";
	}

	$cursor = $db->submission->find(array("studentID" => $studentID,
		"quizID" => $quizID, "questionNumber" => $questionNumber));


	/* 	===============================================================
		Check num submission
		=============================================================== */	
	$currDate = date("Y-m-d");
	$currTime = date("h:i");

	/*if ($cursor.count() > $numSubmission) {
		$object["success"] = false;
		$object["message"] = "exceeded number of submission";
	}
	else {*/

		$myFile = fopen($studentFile, "w");
		fwrite($myFile, $submission);
		fclose($myFile);




		/* 	===============================================================
			Run their code and return
			=============================================================== */

		$str = "python os-system-calls.py " . $studentFile . " " . $gradeFile . " " $language;
		exec($str, $op);




		/* 	===============================================================
			Read Output
			=============================================================== */

		$object = array();
		$outputFile = $quizID . $id . $questionNumber . ".txt";
		if (file_exists($outputFile)) {
			$object["success"] = true;
			$object["message"] = "results are found";
			$object["result"] = file_get_contents($outputFile);
		}
		else {
			$object["success"] = false;
			$object["message"] = "results file are not found";
			$object["result"] = "";
		}




		/* 	===============================================================
			Save Students file into database
			=============================================================== */
		
		$db = $mongo->selectDB("capstone");

		// Allow students to submit even after time limit
		$cursor = $db->submission->insert(array("studentID" => $studentID,
			"quizID" => $quizID, "questionNumber" => $questionNumber, 
			"code" => $submission,
			"result" => $object["result"], "submitTime" => $currTime,
			"submitDate" => $currDate));





		/* 	===============================================================
			Delete student file
			=============================================================== */
		if (file_exists($studentFile)) {
			unlink($studentFile);
		}
		if (file_exists($outputFile)) {
			unlink($outputFile);
		}
	/*}*/

	echo json_encode($object);

?>