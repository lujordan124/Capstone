<?php

	require "CheckLogin.php";

	/* 	===============================================================
		Get quizID or redirect
		=============================================================== */
	if (!isset($_POST["quizID"])) {
		$newURL = "error.html";
		header("Location: '.$newURL");
	}
	$quizID = $_POST["quizID"];





	/* 	===============================================================
		Get mongo object - quizzes (collection)
		=============================================================== */
	$mongo = new MongoClient(); 
	$db = $mongo->selectDB("capstone");
	$cursor = $db->quizzes->find(array("quizID" => $quizID));






	/* 	===============================================================
		Create quiz object
			<list> 		question
			<list> 		numSubmission
			<int> 		timeAllowed
			<string> 	quizName
			<list> 		beginTime
			<list> 		beginDate
			<list> 		endTime
			<list>		endDate
			<list> 		sectionNumber
			<int>		retake
			<string> 	language
		=============================================================== */
	$quiz = array(); // OBJECT
	$numSubmission = array();
	$question = array();


	/* 	===============================================================
		Get quiz object - using quizID
			Check if it there is a quiz
		=============================================================== */
	$found = false;
	foreach ($cursor as $document) {
		$numSubmission = $document["numSubmission"];
		$question = $document["question"];
		$quizName = $document["quizName"];
		$timeAllowed = $document["timeAllowed"];
		$beginTime = $document["beginTime"];
		$beginDate = $document["beginDate"];
		$endTime = $document["endTime"];
		$endDate = $document["endDate"];
		$sectionNumber = $document["sectionNumber"];
		$retake = $document["retake"];
		$language = $document["language"];
		$found = true;
	}

	$index = array_search($MysectionNumber, $sectionNumber);

	/* 	===============================================================
		Check if the student can take the quiz
		=============================================================== */

	if ($found) {
		// CHECK DATE
		$currDate = date("Y-m-d");
		$currTime = date("h:i");

		$MybeginDate = $beginDate[$index];
		$MybeginTime = $beginTime[$index];
		$MyendDate = $endDate[$index];
		$MyendTime = $endTime[$index];

		$allowed = false;
		if ($MybeginDate < $currDate && $currDate < $MyendDate){
			$allowed = true;
		}
		else if ($MybeginDate == $currDate) {
			if ($MybeginTime <= $currTime) {
				$allowed = true;
			}
			else {
				$quiz["message"] = "Can't take the quiz yet";	
			}
		}
		else if ($currDate == $MyendDate) {
			if ($MyendTime > $currTime) {
				$allowed = true;
			}
			else {
				$quiz["message"] = "Too late to take the quiz";	
			}
		}
		else {
			if ($MybeginDate > $currDate) {
				$quiz["message"] = "Can't take the quiz yet";	
			}
			else {
				$quiz["message"] = "Too late to take the quiz";
			}	
		}
		if ($allowed) {

			$cursor = $db->quizSubmission->find(array("studentID" => $studentID,
					"quizID" => $quizID));
			$taken = $cursor->count();

			// End earlier quizzes
			if ($taken > 0) {
				$cursor = $db->quizSubmission->find(array("studentID" => $studentID,
					"quizID" => $quizID,
					"numSubmission" => $taken));
				foreach ($cursor as $document) {
					$finished = $document["finished"];
				}
				if (!$finished) {
					$db->quizSubmission->update(array("studentID" => $studentID,
					"quizID" => $quizID,
					"numSubmission" => $taken),
					array("$set" => array("finished" => true, "endDate" => $currDate, "endTime" => $currTime)));
				}
			}
			// CAN STUDENT RETAKE THIS
			if ($taken < $retake) {

				$db->quizSubmission->insert(array(
					"studentID" => $studentID,
					"quizID" => $quizID,
					"beginDate" => $currDate,
					"beginTime" => $currTime,
					"numSubmission" => $taken,
					"finished" => false
					));

				$quiz["numSubmission"] = $numSubmission;
				$quiz["question"] = $question;
				$quiz["quizName"] = $quizName;
				$quiz["timeAllowed"] = $timeAllowed * $MyextraTime;
				$quiz["beginDate"] = $beginDate;
				$quiz["beginTime"] = $beginTime;
				$quiz["endDate"] = $endDate;
				$quiz["endTime"] = $endTime;
				$quiz["sectionNumber"] = $sectionNumber;
				$quiz["retake"] = $retake;
				$quiz["language"] = $language;
			}
			else {
				$quiz["success"] = false;
				$quiz["message"] = "Exceeded number of quizzes you can take";
			}
			
		}
		else {
			$quiz["success"] = false;
		}

	}
	else {
		$quiz["success"] = false;
		$quiz["message"] = "Did not find the quiz item";

	}
	/* 	===============================================================
		Send (quiz) object
			<list> 		question
			<list> 		numSubmission
			<int> 		timeAllowed
			<string> 	quizName
			<list> 		beginTime
			<list> 		beginDate
			<list> 		endTime
			<list>		endDate
			<list> 		sectionNumber
			<int>		retake
			<bool> success: True if successful, false if unsuccessful
			<string> message: Message of what happened.
		=============================================================== */
	echo json_encode($quiz);



	/* SUMMARY DASH VIEW FOR TA + EXCEPTIONS */
	/* SOME COURSE INFO */
	

?>