<?php

	/* 	===============================================================
		Check login
		=============================================================== */

	require "CheckLogin.php";



	/* 	===============================================================
		Get quizID or redirect
		=============================================================== */
	
	if (!isset($_POST["quizID"])) {
		$newURL = "error.html";
		header("Location: '.$newURL");
	}
	$quizID = $_POST["quizID"];
	
	/* 	===============================================================
		Update endTime and endDate
		=============================================================== */

		$cursor = $db->quizSubmission->find(array("studentID" => $studentID,
				"quizID" => $quizID));
		$taken = $cursor->count()-1;


		$currDate = date("Y-m-d");
		$currTime = date("h:i");

		$db->quizSubmission->update(array("studentID" => $studentID,
					"quizID" => $quizID,
					"numSubmission" => $taken),
					array("$set" => array("finished" => true, "endDate" => $currDate, "endTime" => $currTime)));


	echo "success";

?>