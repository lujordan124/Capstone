<?php

	$MystudentID = "jl4vw";
	$MyclassID = "CS3330";
	$MysectionNumber = 1;
	$MyextraTime = 1.0;
?>