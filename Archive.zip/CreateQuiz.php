<?php

	require "CheckLogin.php";

	/* 	===============================================================
		Get all the inputs
		=============================================================== */
	if (!isset($_POST["quizID"])) {
		$newURL = "error.html";
		header("Location: '.$newURL");
	}
	$teacherID = "luther"; // ERASE
	$quizID =  "";      //$_POST["quizID"]; // MAY HAVE TO ERASE
	$classID = $_POST["classID"];
	$quizName = $_POST["quizName"];
	$timeAllowed = $_POST["timeAllowed"];
	$question = $_POST["question"];
	$numSubmission = $_POST["numSubmission"];
	$answer = $_POST["answer"];
	$retake = $_POST["retake"];
	$beginTime = $_POST["beginTime"];
	$beginDate = $_POST["beginDate"];
	$endDate = $_POST["endDate"];
	$endTime = $_POST["endTime"];
	$sectionNumber = $_POST["sectionNumber"];
	$language = $_POST["language"];

	$size = $answer.count();





	/* 	===============================================================
		Create the quiz
		=============================================================== */
	$mongo = new MongoClient(); 
	$db = $mongo->selectDB("capstone");

	$cursor = $db->quizzes->find(array("classID" => $classID));
	// Create Quiz ID
	$quizID = $classID . $cursor->count();

	$db->quizzes->insert(array(
		"teacherID" => $teacherID,
		"quizID" => $quizID,
		"classID" => $classID,
		"quizName" => $quizName,
		"timeAllowed" => $timeAllowed,
		"question" => $question,
		"numSubmission" => $numSubmission,
		"answer" => $answer,
		"beginTime" => $beginTime,
		"beginDate" => $beginDate,
		"endTime" => $endTime,
		"endDate" => $endDate,
		"sectionNumber" => $sectionNumber,
		"language" => $language
		));

	/* 	===============================================================
		Create Main/Answer file if it doesn't exist.
		=============================================================== */
	
	for ($i = 1; $i <= $size; $i++) {
		$gradeFile = $quizID . $i . ".c";
		if (!file_exists($gradeFile)) {
			$myFile = fopen($gradeFile, "w");
			fwrite($myFile, $answer[$i-1]);
			fclose($myFile);
		}
	}

?>