<?php

	require "CheckLoginInstructor.php";

	/* 	===============================================================
		Get the quizID
		=============================================================== */

	$question = array();
	$answer = array();
	$numSubmission = array();
	$beginTime = array();
	$beginDate = array();
	$endDate = array();
	$endTime = array();
	$lateDate = array();
	$lateTime = array();
	$sectionNumber = array();

	$quizID =  $_POST["quizID"];

	/* 	===============================================================
		View the quiz
		=============================================================== */
	$mongo = new MongoClient(); 
	$db = $mongo->selectDB("capstone");

	$cursor = $db->quizzes->find(array("quizID" => $quizID));

	if ($cursor->count() > 0) {
		$object["success"] = true;
		$object["message"] = "found the quiz";

		foreach ($cursor as $document) {

			$classID = $document["classID"];
			$quizName = $document["quizName"];
			$timeAllowed = $document["timeAllowed"];	
			$question = $document["question"];
			$numSubmission = $document["numSubmission"];
			$answer = $document["answer"];
			$retake = $document["retake"];
			$beginTime = $document["beginTime"];
			$beginDate = $document["beginDate"];
			$endDate = $document["endDate"];
			$endTime = $document["endTime"];
			$lateDate = $document["lateDate"];
			$lateTime = $document["lateTime"];
			$sectionNumber = $document["sectionNumber"];
			$language = $document["language"];

		}

		$object["classID"] = $classID;
		$object["quizName"] = $quizName;
		$object["timeAllowed"] = $timeAllowed;
		$object["question"] = $question;
		$object["numSubmission"] = $numSubmission;
		$object["answer"] = $answer;
		$object["retake"] = $retake;
		$object["beginTime"] = $beginTime;
		$object["beginDate"] = $beginDate;
		$object["endDate"] = $endDate;
		$object["endTime"] = $endTime;
		$object["lateDate"] = $lateDate;
		$object["lateTime"] = $lateTime;
		$object["sectionNumber"] = $sectionNumber;
		$object["language"] = $language;
	}
	else {
		$object["success"] = false;
		$object["message"] = "Dit not find the quiz";
	}

	echo json_encode($object);

?>