<?php

	/* 	===============================================================
		Check login
		=============================================================== */
	$quizID = $_POST["quizID"];
	require "CheckLogin.php";


	$questionNumber = $_POST["questionNumber"];
	$submission = $_POST["submission"];
	$grade = $_POST["grade"]; 
	


	/* 	===============================================================
		Create student's file submission based on language requirement
		=============================================================== */	

	$mongo = new MongoClient(); 
	$db = $mongo->selectDB("capstone");
	$cursor = $db->quizzes->find(array("quizID" => $quizID));

	foreach ($cursor as $document) {
		$language = $document["language"];
		$numSubmission = $document["numSubmission"];
	}

	if ($language == "C") {
		$studentFile = $quizID . $studentID . $questionNumber . ".c";
		$gradeFile = $quizID . $questionNumber . ".c";
	}
	else {
		$studentFile = $quizID . $id . $questionNumber . ".c";
		$gradeFile = $quizID . $questionNumber . ".c";
	}

	$currDate = date("Y-m-d");
	$currTime = date("h:i");


	$myFile = fopen($studentFile, "w");
	fwrite($myFile, $submission);
	fclose($myFile);




	/* 	===============================================================
		Run their code and return
		=============================================================== */

	$str = "python os-system-calls.py " . $studentFile . " " . $gradeFile . " " . $language;
	//$str = "python os-system-calls.py " . $studentFile . " " . $gradeFile;
	exec($str, $op);




	/* 	===============================================================
		Read Output
		=============================================================== */

	$object = array();
	$outputFile = $quizID . $id . $questionNumber . ".txt";
	if (file_exists($outputFile)) {
		$object["success"] = true;
		$object["message"] = "results are found";
		$object["result"] = file_get_contents($outputFile);
	}
	else {
		$object["success"] = false;
		$object["message"] = "results file are not found";
		$object["result"] = "";
	}




	/* 	===============================================================
		Save Students file into database
		=============================================================== */
		
	$db = $mongo->selectDB("capstone");

	if ($grade) {
		$cursor = $db->submission->insert(array(
			"studentID" => $studentID,
			"quizID" => $quizID, 
			"questionNumber" => $questionNumber, 
			"graded" => true,
			"code" => $submission,
			"result" => $object["result"], 
			"submitTime" => $currTime,
			"submitDate" => $currDate,
			"save" => false));
	}
	else {

		$cursor = $db->submission->find(array(
			"studentID" => $studentID,
			"quizID" => $quizID,
			"questionNumber" => $questionNumber,
			"graded" => false
			));
		if ($cursor->count() > 0) {
			$db->submission->remove(array(
				"studentID" => $studentID,
				"quizID" => $quizID,
				"questionNumber" => $questionNumber,
				"graded" => false
				));
		}
		$db->submission->insert(array(
			"studentID" => $studentID,
			"quizID" => $quizID, 
			"questionNumber" => $questionNumber, 
			"code" => $submission,
			"submitTime" => $currTime,
			"submitDate" => $currDate,
			"result" => $object["result"],
			"graded" => false,
			"save" => false
			));
	}





	/* 	===============================================================
		Delete student file
		=============================================================== */
	if (file_exists($studentFile)) {
		unlink($studentFile);
	}
	if (file_exists($outputFile)) {
		unlink($outputFile);
	}


	echo json_encode($object);

?>