<?php

	/* 	===============================================================
		Check login
		=============================================================== */

	$quizID = $_POST["quizID"];
	require "CheckLogin.php";


	/* 	===============================================================
		Get quizID or redirect
		=============================================================== */
	
	$code = array();
	$code = $_POST["code"];


	/* 	===============================================================
		Save the quiz into submission collection
		=============================================================== */

	$currDate = date("Y-m-d");
	$currTime = date("h:i");

	$mongo = new MongoClient(); 
	$db = $mongo->selectDB("capstone");

	for ($i = 0; $i < count($code); $i++) {


		$cursor = $db->submission->find(array(
			"studentID" => $studentID,
			"quizID" => $quizID,
			"questionNumber" => $i+1,
			"graded" => false
			));
		if ($cursor->count() > 0) {
			$db->submission->remove(array(
				"studentID" => $studentID,
				"quizID" => $quizID,
				"questionNumber" => $i+1,
				"graded" => false
				));
		}
		$db->submission->insert(array(
			"studentID" => $studentID,
			"quizID" => $quizID, 
			"questionNumber" => $i+1, 
			"code" => $code[$i],
			"submitTime" => $currTime,
			"submitDate" => $currDate,
			"result" => "",
			"graded" => false,
			"save" => true
			));
	}
	echo "success";

?>