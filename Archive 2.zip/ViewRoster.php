<?php

	/* 	===============================================================
		Check login
		=============================================================== */

	require "CheckLoginInstructor.php";

	/* 	===============================================================
		Get all the inputs
		=============================================================== */

	$studentName = array();
	$studentID = array();
	$sectionNumber = array();
	$extraTime = array();
	$email = array();
	$ta = array();

	$classID = $_POST["classID"];

	/* 	===============================================================
		View the roster
		=============================================================== */
	$mongo = new MongoClient(); 
	$db = $mongo->selectDB("capstone");

	$cursor = $db->roster->find(array("classID" => $classID));

	if ($cursor->count() > 0) {
		$object["success"] = true;
		$object["message"] = "found the class";
		foreach ($cursor as $document) {

			$studentName[] = $document["studentName"];
			$studentID[] = $document["studentID"];	
			$sectionNumber[] = $document["sectionNumber"];
			$extraTime[] = $document["extraTime"];
			$email[] = $document["email"];
			$ta[] = $document["ta"];
		}

		$object["studentName"] = $studentName;
		$object["studentID"] = $studentID;
		$object["sectionNumber"] = $sectionNumber;
		$object["extraTime"] = $extraTime;
		$object["email"] = $email;
		$object["ta"] = $ta;

	}
	else {
		$object["success"] = false;
		$object["message"] = "Dit not find the roster";
	}
	echo json_encode($object);
?>