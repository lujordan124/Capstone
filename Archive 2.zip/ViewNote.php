<?php

	/* 	===============================================================
		Check login
		=============================================================== */

	$quizID = $_POST["quizID"];

	require "CheckLoginGrader.php";



	/* 	===============================================================
		Gets the list of students, their notes, and if they are excused
		=============================================================== */

	$mongo = new MongoClient(); 
	$db = $mongo->selectDB("capstone");

	$cursor = $db->quizzes->find(array("quizID" => $quizID));
	if ($cursor->count() > 0) {

		$cursor = $db->allowed->find(array("quizID" => $quizID));

		$studentID = array();
		$notes = array();
		$lateAllowed = array();
		$exitAllowed = array();
		$moreAllowed = array();
		$lateDateAllowed = array();
		$retakeAllowed = array();
		$object = array();

		foreach ($cursor as $document) {
			$studentID[] = $document["studentID"];
			$notes[] = $document["notes"];
			$lateAllowed[] = $document["lateAllowed"];
			$exitAllowed[] = $document["exitAllowed"];
			$moreAllowed[] = $document["moreAllowed"];
			$lateDateAllowed[] = $document["lateDateAllowed"];
			$retakeAllowed[] = $document["retakeAllowed"];
		}
	
		$object["studentID"] = $studentID;
		$object["notes"] = $notes;
		$object["lateAllowed"] = $lateAllowed;
		$object["exitAllowed"] = $exitAllowed;
		$object["moreAllowed"] = $moreAllowed;
		$object["lateDateAllowed"] = $lateDateAllowed;
		$object["retakeAllowed"] = $retakeAllowed;
	}
	else {
		$object["success"] = false;
		$object["message"] = "Dit not find the quiz";
	}

	echo json_encode($object);

?>