<?php

	/* 	===============================================================
		Check login
		=============================================================== */
	$quizID = $_POST["quizID"];
	require "CheckLogin.php";


	$object = array();
	
	/* 	===============================================================
		Update endTime and endDate
		=============================================================== */
	$cursor = $db->quizSubmission->find(array(
			"studentID" => $studentID,
			"quizID" => $quizID,
			"finished" => false
			));



	$cursor = $db->quizSubmission->find(array(
			"studentID" => $studentID,
			"quizID" => $quizID, 
			"finished" => false));

	if ($cursor->count() > 0) {

		$currDate = date("Y-m-d");
		$currTime = date("h:i");

		$newdata = array('$set' => array(
			"finished" => true,
			"endDate" => $currDate,
			"endTime" => $currTime
			));
		$db->quizSubmission->update(array(
				"studentID" => $studentID,
				"quizID" => $quizID,
				"finished" => false),
				$newdata);

		$object["success"] = true;
		$object["message"] = "finished the quiz";

	}
	else {
		$object["success"] = false;
		$object["message"] = "no test exists that is still active";
	}

	echo json_encode($object);

?>