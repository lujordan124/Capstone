<?php

	/* 	===============================================================
		Check login
		=============================================================== */

	require "CheckLoginInstructor.php";

	/* 	===============================================================
		Get all the inputs
		=============================================================== */
	
	$question = array();
	$answer = array();
	$numSubmission = array();
	$beginTime = array();
	$beginDate = array();
	$endDate = array();
	$endTime = array();
	$lateDate = array();
	$lateTime = array();
	$sectionNumber = array();
	$object = array();


	$quizID = $_POST["quizID"];
	$classID = $_POST["classID"];
	$quizName = $_POST["quizName"];
	$timeAllowed = $_POST["timeAllowed"];	
	$question = $_POST["question"];
	$numSubmission = $_POST["numSubmission"];
	$answer = $_POST["answer"];
	$retake = $_POST["retake"];
	$beginTime = $_POST["beginTime"];
	$beginDate = $_POST["beginDate"];
	$endDate = $_POST["endDate"];
	$endTime = $_POST["endTime"];
	$lateDate = $_POST["lateDate"];
	$lateTime = $_POST["lateTime"];
	$sectionNumber = $_POST["sectionNumber"];
	$language = $_POST["language"];

	$size = count($question);

	/* 	===============================================================
		Edit the quiz
		=============================================================== */
	$mongo = new MongoClient(); 
	$db = $mongo->selectDB("capstone");

	$db->roster->remove(array("quizID" => $quizID));

	$db->quizzes->insert(array(
		"teacherID" => $teacherID,
		"quizID" => $quizID,
		"classID" => $classID,
		"quizName" => $quizName,
		"timeAllowed" => $timeAllowed,
		"question" => $question,
		"numSubmission" => $numSubmission,
		"answer" => $answer,
		"retake" => $retake,
		"beginTime" => $beginTime,
		"beginDate" => $beginDate,
		"endTime" => $endTime,
		"endDate" => $endDate,
		"lateTime" => $lateTime,
		"lateDate" => $lateDate,
		"sectionNumber" => $sectionNumber,
		"language" => $language
		));


	/* 	===============================================================
		Create new Main/Answer file (delete first)
		=============================================================== */
	
	for ($i = 1; $i <= 100; $i++) {
		$gradeFile = $quizID . $i . ".c";
		if (file_exists($gradeFile)) {
			unlink($gradeFile);
		}
	}
	for ($i = 1; $i <= $size; $i++) {
		$gradeFile = $quizID . $i . ".c";
		$myFile = fopen($gradeFile, "w");
		fwrite($myFile, $answer[$i-1]);
		fclose($myFile);
	}


	$object["success"] = true;
	$object["message"] = "edited";
	echo json_encode($object);


?>